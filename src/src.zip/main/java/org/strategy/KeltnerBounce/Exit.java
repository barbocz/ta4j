package org.strategy.KeltnerBounce;

import org.ta4j.core.Rule;
import org.ta4j.core.trading.rules.CrossedDownIndicatorRule;
import org.ta4j.core.trading.rules.CrossedUpIndicatorRule;

public class Exit extends IndicatorSet {


    public Exit(){
//        ruleForBuy = new CrossedUpIndicatorRule(highPriceIndicator, kcM);
    }

}
