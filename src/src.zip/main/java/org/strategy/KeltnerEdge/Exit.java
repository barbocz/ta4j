package org.strategy.KeltnerEdge;

import org.strategy.AbstractExit;

public class Exit extends AbstractExit {
}
