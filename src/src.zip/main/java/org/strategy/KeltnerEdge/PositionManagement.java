package org.strategy.KeltnerEdge;

import org.strategy.AbstractPositionManagement;

public class PositionManagement extends AbstractPositionManagement {
}
