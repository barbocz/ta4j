package org.strategy;

import org.ta4j.core.Rule;

public class TestStrategy {


}
