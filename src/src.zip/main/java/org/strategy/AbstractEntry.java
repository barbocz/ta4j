package org.strategy;

import org.ta4j.core.Rule;

public class AbstractEntry {
    public Rule ruleForSell=null,ruleForBuy=null;

}
