package org.test;

public interface OnSeriesTick {
    void onTickEvent(String message);
}
