package org.ta4j.core;

public class TakeProfit extends ExitLevel {
    TakeProfit(Order order){
        this.order=order;
    }
}
