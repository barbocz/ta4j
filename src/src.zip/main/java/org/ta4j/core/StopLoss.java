package org.ta4j.core;

public class StopLoss extends ExitLevel {
    StopLoss(Order order){
        this.order=order;
    }
}
